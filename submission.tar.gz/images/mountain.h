/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 mountain mountain.png 
 * Time-stamp: Wednesday 04/02/2025, 19:16:39
 * 
 * Image Information
 * -----------------
 * mountain.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MOUNTAIN_H
#define MOUNTAIN_H

extern const unsigned short mountain[625];
#define MOUNTAIN_SIZE 1250
#define MOUNTAIN_LENGTH 625
#define MOUNTAIN_WIDTH 25
#define MOUNTAIN_HEIGHT 25

#endif

