/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=100x70 cowboy cowboy.png 
 * Time-stamp: Thursday 04/03/2025, 14:19:24
 * 
 * Image Information
 * -----------------
 * cowboy.png 100@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef COWBOY_H
#define COWBOY_H

extern const unsigned short cowboy[7000];
#define COWBOY_SIZE 14000
#define COWBOY_LENGTH 7000
#define COWBOY_WIDTH 100
#define COWBOY_HEIGHT 70

#endif

