/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 steve steve.png 
 * Time-stamp: Tuesday 04/01/2025, 22:54:44
 * 
 * Image Information
 * -----------------
 * steve.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STEVE_H
#define STEVE_H

extern const unsigned short steve[100];
#define STEVE_SIZE 200
#define STEVE_LENGTH 100
#define STEVE_WIDTH 10
#define STEVE_HEIGHT 10

#endif

