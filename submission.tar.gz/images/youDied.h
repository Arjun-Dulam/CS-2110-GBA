/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 youDied youDied.png 
 * Time-stamp: Wednesday 04/02/2025, 14:22:43
 * 
 * Image Information
 * -----------------
 * youDied.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef YOUDIED_H
#define YOUDIED_H

extern const unsigned short youDied[38400];
#define YOUDIED_SIZE 76800
#define YOUDIED_LENGTH 38400
#define YOUDIED_WIDTH 240
#define YOUDIED_HEIGHT 160

#endif

