/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 boulder boulder.png 
 * Time-stamp: Wednesday 04/02/2025, 13:10:56
 * 
 * Image Information
 * -----------------
 * boulder.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOULDER_H
#define BOULDER_H

extern const unsigned short boulder[100];
#define BOULDER_SIZE 200
#define BOULDER_LENGTH 100
#define BOULDER_WIDTH 10
#define BOULDER_HEIGHT 10

#endif

