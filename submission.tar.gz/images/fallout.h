/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 fallout fallout.png 
 * Time-stamp: Wednesday 04/02/2025, 19:48:07
 * 
 * Image Information
 * -----------------
 * fallout.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FALLOUT_H
#define FALLOUT_H

extern const unsigned short fallout[38400];
#define FALLOUT_SIZE 76800
#define FALLOUT_LENGTH 38400
#define FALLOUT_WIDTH 240
#define FALLOUT_HEIGHT 160

#endif

