/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=120x80 sisyphus sisyphus.png 
 * Time-stamp: Tuesday 04/01/2025, 21:42:37
 * 
 * Image Information
 * -----------------
 * sisyphus.png 120@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SISYPHUS_H
#define SISYPHUS_H

extern const unsigned short sisyphus[9600];
#define SISYPHUS_SIZE 19200
#define SISYPHUS_LENGTH 9600
#define SISYPHUS_WIDTH 120
#define SISYPHUS_HEIGHT 80

#endif

